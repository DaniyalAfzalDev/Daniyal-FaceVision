import React from 'react'

const User = () => {
  return (
    <div>
      <h2>user settings</h2>
    </div>
  )
}

export default User
